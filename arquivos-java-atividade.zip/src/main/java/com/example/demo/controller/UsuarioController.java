package com.example.demo.controller;

import com.example.demo.dto.UsuarioCadastroDTO;
import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository repository;

    @PostMapping
    public ResponseEntity<Void> criarUsuario(@RequestBody UsuarioCadastroDTO dto) {

        // Conversão: DTO -> Entidade
        Usuario usuario = new Usuario();
        usuario.setNome(dto.getNome());
        usuario.setEmail(dto.getEmail());
        usuario.setSenha(dto.getSenha());
        // id e isAdmin NÃO são copiados: o id é gerado pelo banco
        // e o isAdmin continua false (valor padrão da entidade)

        repository.save(usuario);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
